<script setup>

</script>
<template>
  <footer class="bg-white border-t border-gray-200 py-10">
    <div class="max-w-7xl mx-auto px-8 flex flex-col md:flex-row md:items-center md:justify-between gap-3 text-sm text-gray-600">
      <p class="font-semibold text-gray-900">© Poticard</p>
      <div class="flex gap-4">
        <a class="hover:text-gray-900" href="#terms">이용약관</a>
        <a class="hover:text-gray-900" href="#privacy">개인정보처리방침</a>
        <a class="hover:text-gray-900" href="#support">고객센터</a>
      </div>
    </div>
  </footer>
</template>


<style scoped>

</style>