<script setup>
import { onMounted, ref, toRaw } from 'vue'
import api from '@/api/namecard/index'
const getCandidates = async () => {
  const candidates = ref([]) // { name: '', role: '', bg: '', tags: '' }
  const res = await api.getNamecardInfo()

  candidates.value = res.data.map((item) => {
    return {
      name: item.name,
      role: item.affiliation,
      bg: 'bg-pastel-yellow',
      tags: item.keywords,
    }
  })

  // console.log(candidates.value)
  return candidates
}

onMounted(async () => {
  const namecards = await getCandidates()
  const candidates = namecards.value

  function createCard(data, index, zIndexBase, overlapClass, rotateRange = 10) {
    const seed = data.name + index
    const rotate = Math.random() * rotateRange * 2 - rotateRange

    const card = document.createElement('div')
    // 디자인 변경: 둥근 모서리 강화(rounded-2xl), 테두리 및 그림자 조정
    const isSpecial = data.bg.includes('pastel')
    const borderColor = isSpecial ? 'border-yellow-200' : 'border-gray-100'
    const textColor = isSpecial ? 'text-gray-900' : 'text-gray-800'

    card.className = `card-item relative w-64 h-40 ${data.bg} rounded-2xl shadow-xl border ${borderColor} flex-shrink-0 flex flex-col p-5 overflow-hidden ${overlapClass}`

    card.style.zIndex = zIndexBase + index
    card.style.transform = `rotate(${rotate}deg)`

    card.innerHTML = `
                <div class="flex items-start justify-between gap-3 mb-2">
                    <div class="flex items-center gap-3">
                        <img src="https://api.dicebear.com/9.x/avataaars/svg?seed=${seed}" class="w-10 h-10 rounded-full bg-gray-50 p-0.5 border border-gray-100" alt="Avatar">
                        <div>
                            <h4 class="font-bold ${textColor} text-base leading-tight">${data.name}</h4>
                            <p class="text-[10px] text-gray-500  font-medium tracking-wide uppercase">${data.role}</p>
                        </div>
                    </div>
                    ${isSpecial ? '<span class="text-lg">⭐</span>' : ''}
                </div>
                
                <div class="mt-auto">
                    <div class="flex gap-1.5 flex-wrap">
                        ${data.tags
                          .map(
                            (tag) => `
                            <span class="px-2 py-0.5 ${isSpecial ? 'bg-white/50' : 'bg-gray-50'} 
                            text-gray-600 text-[10px] font-bold rounded border border-transparent">
                                #${tag}
                            </span>
                        `,
                          )
                          .join('')}
                    </div>
                </div>
            `
    return card
  }

  const row1 = document.getElementById('row1-container')
  ;[candidates[1], candidates[0], candidates[2]].forEach((data, i) => {
    const card = createCard(data, i, 10, i === 0 ? '' : '-ml-24', 6)
    row1.appendChild(card)
  })

  const row2 = document.getElementById('row2-container')
  const row2Data = [...candidates.slice(3, 7), candidates[0]]
  row2Data.forEach((data, i) => {
    const card = createCard(data, i, 20, i === 0 ? '' : '-ml-32', 8)
    row2.appendChild(card)
  })

  const row3 = document.getElementById('row3-container')
  const row3Data = [...candidates, ...candidates]
  row3Data.forEach((data, i) => {
    const card = createCard(data, i, 30, i === 0 ? '' : '-ml-40', 10)
    row3.appendChild(card)
  })

  // <![CDATA[  <-- For SVG support
  if ('WebSocket' in window) {
    ;(function () {
      function refreshCSS() {
        var sheets = [].slice.call(document.getElementsByTagName('link'))
        var head = document.getElementsByTagName('head')[0]
        for (var i = 0; i < sheets.length; ++i) {
          var elem = sheets[i]
          var parent = elem.parentElement || head
          parent.removeChild(elem)
          var rel = elem.rel
          if (
            (elem.href && typeof rel != 'string') ||
            rel.length == 0 ||
            rel.toLowerCase() == 'stylesheet'
          ) {
            var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '')
            elem.href =
              url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + new Date().valueOf()
          }
          parent.appendChild(elem)
        }
      }
      var protocol = window.location.protocol === 'https:' ? 'ws://' : 'wss://'
      var address = protocol + window.location.host + window.location.pathname + '/ws'
      var socket = new WebSocket(address)
      socket.onmessage = function (msg) {
        if (msg.data == 'reload') window.location.reload()
        else if (msg.data == 'refreshcss') refreshCSS()
      }
      if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
        console.log('Live reload enabled.')
        sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true)
      }
    })()
  } else {
    console.error(
      'Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.',
    )
  }
})
</script>

<template>
  <div class="bg-pattern text-gray-800 transition-colors duration-300">
    <div class="flex pt-16 min-h-screen">
      <!-- 2. 좌측 고정 패널 (기업용 필터) -->
      <aside
        class="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-white/90 backdrop-blur border-r border-gray-100 p-6 overflow-y-auto z-40 hidden lg:block transition-colors duration-300"
      >
        <div class="mb-8">
          <h2
            class="text-xs font-black text-point-yellow uppercase tracking-wider mb-6 flex items-center gap-2"
          >
            <span class="w-2 h-2 bg-point-yellow rounded-full"></span> Targeting
          </h2>

          <div class="space-y-6">
            <!-- 필터 그룹 1 -->
            <div>
              <h3 class="font-bold text-gray-800 d mb-3 flex justify-between items-center text-sm">
                직군 (Job Group)
              </h3>
              <div class="space-y-2.5">
                <label
                  class="flex items-center gap-3 cursor-pointer group p-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <input
                    type="checkbox"
                    class="w-4 h-4 rounded border-gray-300 text-yellow-500 focus:ring-yellow-500 bg-gray-100"
                  />
                  <span class="text-sm text-gray-600 group-hover:text-gray-900 transition-colors"
                    >기획/PM</span
                  >
                </label>
                <label
                  class="flex items-center gap-3 cursor-pointer group p-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <input
                    type="checkbox"
                    checked
                    class="w-4 h-4 rounded border-gray-300 text-yellow-500 focus:ring-yellow-500 bg-gray-100"
                  />
                  <span class="text-sm text-gray-600 group-hover:text-gray-900 transition-colors"
                    >디자인</span
                  >
                </label>
                <label
                  class="flex items-center gap-3 cursor-pointer group p-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <input
                    type="checkbox"
                    checked
                    class="w-4 h-4 rounded border-gray-300 text-yellow-500 focus:ring-yellow-500 bg-gray-100"
                  />
                  <span class="text-sm text-gray-600 group-hover:text-gray-900 transition-colors"
                    >개발 (FE/BE)</span
                  >
                </label>
              </div>
            </div>

            <div class="w-full h-px bg-gray-100"></div>

            <!-- 필터 그룹 2 (태그 스타일 변경) -->
            <div>
              <h3 class="font-bold text-gray-800 mb-3 text-sm">필수 스킬</h3>
              <div class="flex flex-wrap gap-2">
                <span
                  class="px-3 py-1.5 bg-yellow-50 dtext-yellow-700 text-xs font-bold rounded-lg cursor-pointer border border-yellow-100 hover:bg-yellow-100 transition-colors"
                  >React</span
                >
                <span
                  class="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-medium rounded-lg cursor-pointer border border-gray-200 hover:bg-gray-100 transition-colors"
                  >Figma</span
                >
                <span
                  class="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-medium rounded-lg cursor-pointer border border-gray-200 hover:bg-gray-100 transition-colors"
                  >Python</span
                >
              </div>
            </div>
          </div>
        </div>

        <!-- 하단 버튼 (Yellow 포인트) -->
        <div class="absolute bottom-6 left-6 right-6">
          <button
            class="w-full py-3 bg-gray-900 text-white rounded-2xl font-black hover:bg-gray-800 shadow-lg transition-all transform hover:-translate-y-1"
          >
            필터 적용하기
          </button>
        </div>
      </aside>

      <!-- 3. 메인 콘텐츠 -->
      <main class="flex-1 lg:ml-64 p-8 overflow-x-hidden">
        <div class="max-w-6xl mx-auto space-y-20">
          <!-- 헤드라인 -->
          <div class="text-center space-y-2 mb-12 pt-8">
            <span
              class="px-3 py-1 rounded-full bg-yellow-100 text-yellow-700 text-xs font-bold tracking-wide"
              >TODAY'S PICK</span
            >
            <h2 class="text-4xl font-black text-gray-900 tracking-tight">
              주목해야 할
              <span class="text-point-yellow relative inline-block">
                인재
                <svg
                  class="absolute w-full h-2 bottom-1 left-0 text-yellow-200 -z-10"
                  viewBox="0 0 100 10"
                  preserveAspectRatio="none"
                >
                  <path
                    d="M0 5 Q 50 10 100 5"
                    stroke="currentColor"
                    stroke-width="8"
                    fill="none"
                    opacity="0.5"
                  />
                </svg>
              </span>
            </h2>
            <p class="text-gray-500">귀사의 팀 컬처와 딱 맞는 멤버를 찾아보세요.</p>
          </div>

          <!-- 첫 번째 줄: 프리미엄 (중앙 정렬) -->
          <div
            class="relative w-full h-72 flex justify-center items-center card-stack perspective-1000"
          >
            <div id="row1-container" class="flex items-center justify-center w-full">
              <!-- JS Cards -->
            </div>
          </div>

          <!-- 두 번째 줄: 라이징 스타 -->
          <div class="space-y-6">
            <div class="flex items-center gap-3 mb-4 px-4">
              <div
                class="w-10 h-10 bg-pastel-yellow rounded-xl flex items-center justify-center text-xl"
              >
                🚀
              </div>
              <div>
                <h3 class="text-xl font-bold text-gray-900">새로 떠오르는 루키</h3>
                <p class="text-xs text-gray-500">빠른 성장세를 보이는 주니어 인재들</p>
              </div>
            </div>
            <div class="relative w-full h-64 flex justify-center items-center card-stack">
              <div id="row2-container" class="flex items-center justify-center w-full pl-10">
                <!-- JS Cards -->
              </div>
            </div>
          </div>

          <!-- 세 번째 줄: 전체 리스트 -->
          <div class="space-y-6 pb-20">
            <div class="flex items-center gap-3 mb-4 px-4">
              <div
                class="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xl"
              >
                👀
              </div>
              <div>
                <h3 class="text-xl font-bold text-gray-900">다양한 분야의 전문가</h3>
                <p class="text-xs text-gray-500">경력직 전문가들을 만나보세요</p>
              </div>
            </div>
            <div class="w-full overflow-x-auto pb-12 pt-4 px-4 scrollbar-hide">
              <div id="row3-container" class="flex min-w-max items-center h-64 pl-20">
                <!-- JS Cards -->
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<style scoped>
body {
  font-family: 'Noto Sans KR', sans-serif;
}
.font-poppins {
  font-family: 'Poppins', sans-serif;
}

/* 스크롤바 커스텀 */
::-webkit-scrollbar {
  width: 8px;
}
::-webkit-scrollbar-track {
  background: transparent;
}
::-webkit-scrollbar-thumb {
  background: #d4d4d8;
  border-radius: 4px;
}
.dark ::-webkit-scrollbar-thumb {
  background: #52525b;
}
::-webkit-scrollbar-thumb:hover {
  background: #a1a1aa;
}

/* 카드 겹침 효과 */
.card-stack:hover .card-item {
  margin-left: -20px;
  transform: rotate(0deg) translateY(-10px);
}

.card-item {
  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
  cursor: pointer;
}

.card-item:hover {
  z-index: 50 !important;
  transform: scale(1.05) translateY(-15px) !important;
  box-shadow:
    0 20px 25px -5px rgba(0, 0, 0, 0.1),
    0 10px 10px -5px rgba(0, 0, 0, 0.04);
  border-color: #facc15 !important;
}

/* 배경 패턴 (다크모드 대응) */
.bg-pattern {
  background-color: #f8fafc;
  background-image: radial-gradient(#cbd5e1 1px, transparent 1px);
  background-size: 24px 24px;
}
.dark .bg-pattern {
  background-color: #18181b;
  background-image: radial-gradient(#3f3f46 1px, transparent 1px);
}
</style>
