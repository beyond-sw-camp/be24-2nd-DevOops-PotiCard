<script setup>
import { reactive } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import api from '@/api/user'

const router = useRouter()

// 회원가입 폼 상태
const joinForm = reactive({
  name: '',
  email: '',
  password: '',
  phone: '',
})

// 전화번호 자동 하이픈
const autoHyphen = (e) => {
  const v = e.target.value
    .replace(/[^0-9]/g, '')
    .replace(/^(\d{0,3})(\d{0,4})(\d{0,4})$/g, '$1-$2-$3')
    .replace(/(\-{1,2})$/g, '')
  e.target.value = v
  joinForm.phone = v 
}

const joinFormInputError = reactive({
  password: {
    errorMessage: "",
    isValid: true,
  },
});

// 비밀번호 제약조건
const passwordrule = () => {
  const pw = joinForm.password;
  if(pw.length < 8) {
    joinFormInputError.password.errorMessage = '8글자 이상 입력해주세요'
    joinFormInputError.password.isValid = false
    return false
  }
  if (!/[A-Za-z]/.test(pw)) {
  joinFormInputError.password.errorMessage = "영문자를 포함해야 합니다.";
  return false;
  }
  if (!/\d/.test(pw)) {
  joinFormInputError.password.errorMessage = "숫자를 포함해야 합니다.";
  return false;
  }
  if (!/[!@#$%^&*]/.test(pw)) {
  joinFormInputError.password.errorMessage = "1개 이상의 특수문자를 포함해야 합니다.";
  return false;
  }
  joinFormInputError.password.errorMessage = ''
  joinFormInputError.password.isValid = true

}

const signup = async () => {
  try {
    const res = await api.signup({
      name: joinForm.name,
      password: joinForm.password,
    })
    console.log('signup 성공:', res)

    //가입 성공 후 로그인으로 이동 
    router.push('/login')
  } catch (e) {
    console.error('signup 실패:', e)
    alert('회원가입 실패')
  }
}
</script>

<template>
  <div class="bg-white dark:bg-zinc-900 text-gray-800 dark:text-gray-100 font-sans transition-colors duration-300">
    <!-- (모달은 일단 동작 안 붙임: 디자인 그대로 유지) -->
    <div id="authModal" class="modal-backdrop" aria-hidden="true">
      <div class="modal-card">
        <div class="rounded-3xl border border-gray-100 dark:border-zinc-800 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md shadow-2xl p-5">
          <div class="flex items-center justify-between mb-4">
            <p class="text-sm font-black text-gray-900 dark:text-white">회원 선택</p>
            <button
              id="authClose"
              class="w-9 h-9 rounded-xl hover:bg-gray-50 dark:hover:bg-zinc-800 flex items-center justify-center"
              aria-label="닫기"
              type="button"
            >
              ✕
            </button>
          </div>
          <div class="grid grid-cols-1 gap-3">
            <RouterLink
              to="/login"
              class="w-full px-4 py-4 rounded-2xl border border-gray-100 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-800/60 hover:border-point-yellow transition text-left block"
            >
              <span class="text-base font-black text-gray-900 dark:text-white">👤 개인</span>
            </RouterLink>
            <RouterLink
              to="/login"
              class="w-full px-4 py-4 rounded-2xl border border-gray-100 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-800/60 hover:border-point-yellow transition text-left block"
            >
              <span class="text-base font-black text-gray-900 dark:text-white">🏢 법인</span>
            </RouterLink>
          </div>
        </div>
      </div>
    </div>

    <main class="flex-1 flex items-center justify-center pt-12 pb-12 px-4">
      <div
        class="w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-zinc-800 overflow-hidden relative"
      >
        <div class="h-2 bg-point-yellow w-full"></div>

        <div class="p-8 md:p-10">
          <div class="text-center mb-8">
            <h2 class="text-3xl font-black font-poppins text-gray-900 dark:text-white mb-2">Join Poticard</h2>
            <p class="text-gray-500 dark:text-gray-400 text-sm">당신의 포트폴리오를 명함 한 장으로 표현하세요.</p>
          </div>

          <!-- ✅ submit 연결 -->
          <form class="space-y-6" @submit.prevent="signup">
            <div class="space-y-2">
              <label class="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Name</label>
              <input
                v-model.trim="joinForm.name"
                type="text"
                placeholder="홍길동"
                class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-zinc-800 border-2 border-transparent focus:border-point-yellow focus:bg-white dark:focus:bg-zinc-900 outline-none transition-all text-gray-900 dark:text-white placeholder-gray-400"
              />
            </div>

            <div class="space-y-2">
              <label class="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Email</label>
              <input
                v-model.trim="joinForm.email"
                type="email"
                placeholder="example@poticard.io"
                class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-zinc-800 border-2 border-transparent focus:border-point-yellow focus:bg-white dark:focus:bg-zinc-900 outline-none transition-all text-gray-900 dark:text-white placeholder-gray-400"
              />
            </div>

            <div class="space-y-2">
              <label class="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Password</label>
              <input
                v-model="joinForm.password" @input="passwordrule"
                type="password"
                placeholder="••••••••"
                class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-zinc-800 border-2 border-transparent focus:border-point-yellow focus:bg-white dark:focus:bg-zinc-900 outline-none transition-all text-gray-900 dark:text-white placeholder-gray-400"
              />
              <p class="text-xs text-red-500 mt-1">
                {{ joinFormInputError.password.errorMessage }}
              </p>
            </div>

            <div class="space-y-2">
              <label class="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Phone</label>
              <input
                v-model="joinForm.phone"
                type="tel"
                @input="autoHyphen"
                id="auto-phone"
                placeholder="숫자만 입력해 주세요"
                pattern="01[016789]-[0-9]{3,4}-[0-9]{4}"
                class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-zinc-800 border-2 border-transparent focus:border-point-yellow focus:bg-white dark:focus:bg-zinc-900 outline-none transition-all text-gray-900 dark:text-white placeholder-gray-400"
              />
            </div>

            <button
              type="submit"
              class="w-full py-4 mt-4 bg-point-yellow text-gray-900 rounded-xl font-bold shadow-lg shadow-yellow-200/50 dark:shadow-none hover:bg-yellow-300 transform hover:-translate-y-0.5 transition-all text-lg"
            >
              포티카드 시작하기
            </button>
          </form>

          <br />

          <div class="mb-8">
            <div class="relative flex items-center justify-center">
              <div class="border-t border-gray-200 dark:border-zinc-700 w-full absolute"></div>
              <span class="bg-white dark:bg-zinc-900 px-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest relative z-10">
                Or join with social
              </span>
            </div>
            <br />
            <div class="flex justify-center gap-4 mb-8">
              <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <i class="fa-brands fa-google text-lg"></i>
              </button>
              <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <i class="fa-brands fa-github text-lg"></i>
              </button>
              <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <i class="fa-brands fa-facebook-f text-lg"></i>
              </button>
              <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group">
                <span class="font-black text-sm font-sans tracking-tighter group-hover:text-point-yellow">N</span>
              </button>
            </div>
          </div>

          <p class="text-center mt-6 text-sm text-gray-400">
            이미 계정이 있으신가요?
            <RouterLink to="/login" class="text-point-yellow hover:underline font-bold">로그인</RouterLink>
          </p>
        </div>
      </div>
    </main>
  </div>
</template>

<style scoped>
:deep(body) {
  font-family: 'Noto Sans KR', sans-serif;
}
.font-poppins {
  font-family: 'Poppins', sans-serif;
}

/* 배경 패턴 (다크모드 대응) */
.bg-pattern {
  background-color: #f8fafc;
  background-image: radial-gradient(#cbd5e1 1px, transparent 1px);
  background-size: 24px 24px;
}
.dark .bg-pattern {
  background-color: #18181b; /* zinc-900 */
  background-image: radial-gradient(#3f3f46 1px, transparent 1px);
}
</style>
