<script setup>
function extractKeywords() {
  const loadingBtn = document.getElementById('extract-btn');
  const tagSection = document.getElementById('keyword-result-section');
  const nextStepBtn = document.getElementById('next-step-btn');
  const editBtn = document.getElementById('top-edit-btn');
  
  if (!loadingBtn || !tagSection || !nextStepBtn) return;

  loadingBtn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> 키워드 분석 중...';
  loadingBtn.disabled = true;

  setTimeout(() => {
    tagSection.classList.remove('hidden');
    tagSection.classList.add('animate-fade-in');
    loadingBtn.classList.add('hidden');
    nextStepBtn.classList.remove('hidden');
    if (editBtn) editBtn.style.display = 'none';
    tagSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 1200);
}
</script>

<template>
<div class="bg-pattern text-gray-800 dark:text-gray-200 flex flex-col min-h-screen">

<div id="app-header"></div>
<div id="authModal" class="modal-backdrop" aria-hidden="true">
<div class="modal-card">
  <div class="rounded-3xl border border-gray-100 dark:border-zinc-800 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md shadow-2xl p-5">
    <div class="flex items-center justify-between mb-4">
      <p class="text-sm font-black text-gray-900 dark:text-white">회원 선택</p>
      <button id="authClose" class="w-9 h-9 rounded-xl hover:bg-gray-50 dark:hover:bg-zinc-800 flex items-center justify-center" aria-label="닫기">✕</button>
    </div>
    <div class="grid grid-cols-1 gap-3">
      <a href="login.html" class="w-full px-4 py-4 rounded-2xl border border-gray-100 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-800/60 hover:border-point-yellow transition text-left block">
        <span class="text-base font-black text-gray-900 dark:text-white">👤 개인</span>
      </a>
      <a href="login.html" class="w-full px-4 py-4 rounded-2xl border border-gray-100 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-800/60 hover:border-point-yellow transition text-left block">
        <span class="text-base font-black text-gray-900 dark:text-white">🏢 법인</span>
      </a>
    </div>
  </div>
</div>
</div>

<main class="flex-1 pt-10 pb-20 px-4">
    <div class="max-w-4xl mx-auto">
        
        <div class="mb-12 max-w-3xl mx-auto">
            <div class="flex justify-between text-sm font-bold text-gray-400 dark:text-gray-500 mb-2 px-1 font-poppins">
                <span>01. 프로젝트 작성</span>
                <span class="text-point-yellow">02. 프로젝트 수정 & 확인</span>
                <span>03. 스타일</span>
            </div>
            <div class="w-full h-1.5 bg-gray-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                <div class="w-2/3 h-full bg-point-yellow rounded-full transition-all duration-700"></div>
            </div>
        </div>

        <div class="bg-white dark:bg-zinc-900 rounded-[2.5rem] shadow-2xl shadow-gray-200/40 dark:shadow-none border border-gray-100 dark:border-zinc-800 p-8 md:p-14 relative">
            
            <div class="flex flex-col md:flex-row md:items-start justify-between mb-16 pb-10 border-b border-gray-50 dark:border-zinc-800 gap-6">
                <div>
                    <div class="inline-flex items-center gap-2 px-3 py-1 bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-500 rounded-full text-[11px] font-bold mb-4">
                        <i class="fa-solid fa-wand-magic-sparkles"></i> AI Content Review
                    </div>
                    <h2 class="text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight mb-3">내용 확정 및 키워드 추출</h2>
                    <p class="text-gray-500 dark:text-gray-400 leading-relaxed text-sm md:text-base">내용이 확정되면 키워드를 추출해 주세요.<br><span class="text-point-yellow font-bold">키워드 추출 후에는 내용 수정이 불가능합니다.</span></p>
                </div>
                <button id="top-edit-btn" class="px-8 py-3 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 text-gray-600 dark:text-gray-300 rounded-2xl font-bold hover:bg-gray-50 dark:hover:bg-zinc-700 transition-all shadow-sm flex items-center justify-center gap-2 shrink-0 text-sm">
                    <i class="fa-solid fa-pen-to-square text-point-yellow"></i> 내용 수정하기
                </button>
            </div>

            <div class="space-y-16 mb-20">
                <div>
                    <h3 class="text-[10px] font-black text-gray-300 dark:text-zinc-600 mb-4 uppercase tracking-[0.2em]">Project Overview</h3>
                    <div class="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                        본 프로젝트는 이커머스 플랫폼의 <span class="ai-highlight">결제 전환율 개선</span>을 목표로 설정하였습니다. 기존의 복잡한 결제 단계를 <span class="ai-highlight">사용자 중심의 원스톱 프로세스</span>로 재설계하여 이탈률을 최소화하였습니다.
                    </div>
                </div>

                <div>
                    <h3 class="text-[10px] font-black text-gray-300 dark:text-zinc-600 mb-4 uppercase tracking-[0.2em]">Key Features</h3>
                    <div class="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                        <span class="ai-highlight">React 기반의 SPA</span> 환경에서 실시간 재고 연동 시스템을 도입했습니다. 사용자가 결제 시점에 정확한 정보를 확인하도록 하여 서비스의 신뢰도를 높였습니다.
                    </div>
                </div>
                
                <div>
                    <h3 class="text-[10px] font-black text-gray-300 dark:text-zinc-600 mb-4 uppercase tracking-[0.2em]">Technical Challenges</h3>
                    <div class="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                        대규모 데이터 렌더링 시 발생하는 병목 현상을 해결하기 위해 <span class="ai-highlight">가상 스크롤(Virtual Scroll)</span> 기법을 적용했습니다. 이를 통해 초기 로딩 속도를 <span class="ai-highlight">40% 이상 개선</span>했습니다.
                    </div>
                </div>

                <div>
                    <h3 class="text-[10px] font-black text-gray-300 dark:text-zinc-600 mb-4 uppercase tracking-[0.2em]">Collaboration</h3>
                    <div class="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                        <span class="ai-highlight">Atomic Design 패턴</span>을 활용한 공통 컴포넌트 라이브러리를 구축하여 디자이너와의 협업 효율을 극대화했습니다.
                    </div>
                </div>

                <div>
                    <h3 class="text-[10px] font-black text-gray-300 dark:text-zinc-600 mb-4 uppercase tracking-[0.2em]">Results & Future</h3>
                    <div class="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                        런칭 후 실제 결제 완료 건수가 <span class="ai-highlight">15% 상승</span>하는 성과를 거두었습니다. 향후 수집된 데이터를 바탕으로 추천 엔진을 고도화할 예정입니다.
                    </div>
                </div>
            </div>

            <div id="keyword-result-section" class="hidden mt-10 p-10 bg-gray-50/50 dark:bg-zinc-800/30 rounded-[2.5rem] border border-gray-100 dark:border-zinc-800 border-dashed relative">
                <div class="absolute -top-4 left-10 px-4 py-1 bg-white dark:bg-zinc-900 border border-gray-100 dark:border-zinc-800 rounded-full text-[10px] font-black text-point-yellow shadow-sm tracking-widest uppercase">
                    Final Tech Keywords
                </div>
                <h4 class="text-sm font-bold text-gray-800 dark:text-white mb-6 flex items-center gap-2">
                    <i class="fa-solid fa-check-circle text-green-500"></i> 내용 확정 및 키워드 추출이 완료되었습니다.
                </h4>
                <div class="flex flex-wrap gap-3">
                    <span class="px-5 py-2.5 bg-white dark:bg-zinc-800 border-2 border-point-yellow/20 text-gray-700 dark:text-gray-300 text-sm rounded-2xl font-bold shadow-sm">#React</span>
                    <span class="px-5 py-2.5 bg-white dark:bg-zinc-800 border-2 border-point-yellow/20 text-gray-700 dark:text-gray-300 text-sm rounded-2xl font-bold shadow-sm">#Virtual Scroll</span>
                    <span class="px-5 py-2.5 bg-white dark:bg-zinc-800 border-2 border-point-yellow/20 text-gray-700 dark:text-gray-300 text-sm rounded-2xl font-bold shadow-sm">#Atomic Design Pattern</span>
                    </div>
            </div>

            <div class="mt-16 flex flex-col md:flex-row justify-between items-center gap-6 pt-10 border-t border-gray-50 dark:border-zinc-800">
                <button type="button" onclick="history.back()" class="px-8 py-3 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 text-gray-500 dark:text-gray-400 rounded-2xl font-bold hover:bg-gray-50 dark:hover:bg-zinc-700 transition-all flex items-center gap-2 text-sm">
                    <i class="fa-solid fa-arrow-left"></i> 이전 단계
                </button>
                
                <div class="flex items-center gap-3 w-full md:w-auto">
                    <button type="button" class="flex-1 md:flex-none px-8 py-3 bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 text-gray-600 dark:text-gray-300 rounded-2xl font-bold hover:bg-gray-50 dark:hover:bg-zinc-700 transition-all">
                        임시 저장
                    </button>
                    
                    <button id="extract-btn" type="button" @click="extractKeywords()" class="flex-1 md:flex-none px-10 py-3 bg-gray-900 dark:bg-zinc-100 text-white dark:text-zinc-900 rounded-2xl font-bold shadow-xl hover:bg-black dark:hover:bg-white transform hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">
                        내용 확정 및 키워드 추출 <i class="fa-solid fa-wand-sparkles text-point-yellow"></i>
                    </button>

                    <a href="portfolio-style" id="next-step-btn" class="hidden flex-1 md:flex-none px-12 py-3 bg-point-yellow text-gray-900 rounded-2xl font-bold shadow-xl shadow-yellow-200/50 hover:bg-yellow-400 transform hover:-translate-y-0.5 transition-all animate-fade-in inline-flex items-center justify-center">
                        스타일 설정하기 <i class="fa-solid fa-chevron-right ml-1 text-sm"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</template>

<style scoped>
:deep(body) { font-family: 'Noto Sans KR', sans-serif; transition: background-color 0.3s ease; }
        .bg-pattern {
            background-color: #fcfcfc;
            background-image: radial-gradient(#e2e8f0 0.8px, transparent 0.8px);
            background-size: 20px 20px;
        }
        /* 다크모드 배경 패턴 변경 */
        .dark .bg-pattern {
            background-color: #121212;
            background-image: radial-gradient(#2d2d2d 0.8px, transparent 0.8px);
        }
        .ai-highlight { 
            background: linear-gradient(to top, #FEF9C3 40%, transparent 40%);
            font-weight: 600;
            color: #1e293b;
        }
        .dark .ai-highlight {
            background: linear-gradient(to top, #3e3a10 40%, transparent 40%);
            color: #fef9c3;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in { animation: fadeIn 0.5s ease-out; }
</style>