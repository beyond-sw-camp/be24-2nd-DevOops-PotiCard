<script setup>
import { reactive } from 'vue'
import { useRouter, useRoute, RouterLink } from 'vue-router'
import api from '@/api/user'
import useAuthStore from '@/stores/useAuthStore'
const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()
const loginForm = reactive({
  name: '',      //
  password: '',
})

const login = async () => {
  try {
    const res = await api.login(loginForm)
    console.log('login 성공:', res.data)
    const userInfo =
      (typeof res.data === 'object' && res.data) ? res.data : { userName: loginForm.name }

    localStorage.setItem('USERINFO', JSON.stringify(userInfo))
    authStore.login(userInfo)

    // 메인페이지로
    const redirect = route.query.redirect || '/'
    router.push(redirect)
  } catch (e) {
    console.error('login 실패:', e)
    alert('로그인 실패')
  }
}
</script>

<template>
  <div class="bg-white dark:bg-zinc-900 text-gray-800 dark:text-gray-100 font-sans transition-colors duration-300">
    <main class="flex-1 flex items-center justify-center pt-12 pb-12 px-4">
      <div
        class="w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-zinc-800 overflow-hidden relative"
      >
        <div class="h-2 bg-point-yellow w-full"></div>

        <div class="p-8 md:p-10">
          <div class="text-center mb-8">
            <h2 class="text-3xl font-black font-poppins text-gray-900 dark:text-white mb-2">Login</h2>
            <p class="text-gray-500 dark:text-gray-400 text-sm">포트폴리오를 관리해보세요.</p>
          </div>

          <!-- ✅ submit 연결 -->
          <form class="space-y-6" @submit.prevent="login">
            <div class="space-y-2">
              <label class="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                Name
              </label>

              <!-- ✅ v-model -->
              <input
                v-model.trim="loginForm.name"
                type="text"
                placeholder="아이디(이름)"
                class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-zinc-800 border-2 border-transparent focus:border-point-yellow focus:bg-white dark:focus:bg-zinc-900 outline-none transition-all text-gray-900 dark:text-white placeholder-gray-400"
              />
            </div>

            <div class="space-y-2">
              <div class="flex justify-between items-center">
                <label class="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                  Password
                </label>
                <a href="#" class="text-xs font-bold text-gray-400 hover:text-point-yellow transition-colors">
                  비밀번호를 잊으셨나요?
                </a>
              </div>

              <!-- ✅ v-model -->
              <input
                v-model="loginForm.password"
                type="password"
                placeholder="••••••••"
                class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-zinc-800 border-2 border-transparent focus:border-point-yellow focus:bg-white dark:focus:bg-zinc-900 outline-none transition-all text-gray-900 dark:text-white placeholder-gray-400"
              />
            </div>

            <button
              type="submit"
              class="w-full py-4 mt-4 bg-point-yellow text-gray-900 rounded-xl font-bold shadow-lg shadow-yellow-200/50 dark:shadow-none hover:bg-yellow-300 transform hover:-translate-y-0.5 transition-all text-lg"
            >
              로그인
            </button>
          </form>

          <br /><br />
          <div class="relative flex items-center justify-center">
            <div class="border-t border-gray-200 dark:border-zinc-700 w-full absolute"></div>
            <span class="bg-white dark:bg-zinc-900 px-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest relative z-10">
              Or login with social
            </span>
          </div>
        </div>

        <div class="mb-8">
          <div class="flex justify-center gap-4 mb-8">
            <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
              <i class="fa-brands fa-google text-lg"></i>
            </button>
            <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
              <i class="fa-brands fa-github text-lg"></i>
            </button>
            <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
              <i class="fa-brands fa-facebook-f text-lg"></i>
            </button>
            <button type="button" class="w-12 h-12 rounded-full bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:border-point-yellow hover:text-point-yellow hover:shadow-lg hover:-translate-y-1 transition-all duration-300 group">
              <span class="font-black text-sm font-sans tracking-tighter group-hover:text-point-yellow">N</span>
            </button>
          </div>

          <p class="text-center mt-6 text-sm text-gray-400">
            아직 계정이 없으신가요?
            <RouterLink to="/signup" class="text-point-yellow hover:underline font-bold">회원가입</RouterLink>
          </p>
        </div>
      </div>
    </main>
  </div>
</template>

<style scoped>
:deep(body) { font-family: 'Noto Sans KR', sans-serif; }
.font-poppins { font-family: 'Poppins', sans-serif; }
.bg-pattern {
  background-color: #f8fafc;
  background-image: radial-gradient(#cbd5e1 1px, transparent 1px);
  background-size: 24px 24px;
}
.dark .bg-pattern {
  background-color: #18181b;
  background-image: radial-gradient(#3f3f46 1px, transparent 1px);
}
</style>
